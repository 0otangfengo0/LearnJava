create
    definer = root@localhost function mock_data() returns int
begin
	declare	num int default 1000000;
	DECLARE	i INT DEFAULT 0;
	while i<num do 
		INSERT INTO `app_user`(`name`,`email`,`phone`,`gender`,`password`,`age`)
		VALUES (CONCAT('用户',i),
		'1234567@qq.com',
		CONCAT('18',FLOOR(RAND()*((999999999-100000000)+1000000000))),
		FLOOR(RAND()*2),
		UUID(),
		FLOOR(RAND()*100));
		set i = i+1;
	end while; 
	return i;
end;

